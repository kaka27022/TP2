#include "pilha.h"

#include <time.h>
#include <stdio.h>
#include <stdlib.h>


int main(void) {
    double tempo;
    clock_t inicio, fim;
    
    inicio = clock();
    srand(time(NULL));


//  [CORPO DO PROGRAMA]
    char opt;
    int lins, cols;
    scanf("%d %d", &lins, &cols);
    Labirinto *lab = alocarLab(lins, cols);
    getchar();
    scanf("%c", &opt);
    getchar();

    switch(opt) {
        case 'p':
            leLabirinto(lab);
            acharSaidaPilha(lab);
            desalocaVisitado(lab);
        break;

        case 'f':
            printf("\nfila");
        break;
    }
    

//  [MEM. FREE] ~~~~~~~~~~
    desalocarLabirinto(&lab);

//  [FUNÇÕES AUXILIARES]
    fim = clock();
    tempo = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
    printf("\nTempo de execucao: %fs\n", tempo);
    
    return 0;
}   

